<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">


<h1 class="text-center">List all information Department</h1>
<a href="<?php echo e(route("dep.create")); ?>" class="btn btn-info" style="margin-bottom: 20px;margin-left:75%;">Add New</a>

<table class="table table-dark table-striped mx-auto" style="width: 70%">
    <thead class="text-center">
        <tr>
            <th>#Id</th>
            <th>Dep_Name</th>
            <th>Manager</th>
            <th>Emp_Name</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody class="text-center">
        <?php $__currentLoopData = $department; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="fw-bold"><?php echo e($dep->id); ?></td>
                <td><?php echo e($dep->dep_name); ?></td>
                <td><?php echo e($dep->manager); ?></td>
                <td><?php echo e($dep->getDepartment->name); ?></td>
                <td>
                   <form action="<?php echo e(route("dep.destroy", $dep->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field("DELETE"); ?>
                        <a href="<?php echo e(route("dep.show", $dep->id)); ?>" class="btn btn-primary">View</a>
                        <a href="<?php echo e(route("dep.edit", $dep->id)); ?>" class="btn btn-success">Edit</a>
                        <button type="submit" class="btn btn-danger">Delete</button>
                   </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\YEAR III\laravel\CRUDLARAVEL\ass2laravel\resources\views/departmentview/depFront.blade.php ENDPATH**/ ?>