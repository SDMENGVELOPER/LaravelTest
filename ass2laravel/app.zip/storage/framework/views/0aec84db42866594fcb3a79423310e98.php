<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

<h1 class="text-center " style="margin-bottom: 20px">View Employee Detail</h1>
<table class="table table-striped table-hover mx-auto border" style="width: 80%">
    <thead>
        <tr>
            <th>#ID</th>
            <th>Name</th>
            <th>Gender</th>
            <th>Salary</th>
            <th>Birth Of Date</th>
            <th>Hire Of Date</th>
            <th>Phone</th>
       </tr>
    </thead>
    <tbody>
        <tr>
            <td class="fw-bold"><?php echo e($param->id); ?></td>
            <td><?php echo e($param->name); ?></td>
            <td><?php echo e($param->gender == "M" ? "Male" : "Female"); ?></td>
            <td><?php echo e($param->salary); ?>$</td>
            <td><?php echo e($param->birth_date); ?></td>
            <td><?php echo e($param->hire_date); ?></td>
            <td><?php echo e($param->phone); ?></td>
        </tr>
    </tbody>

</table>
<div class="mx-auto" style="width:80%">
    <a href="<?php echo e(route("emp.index")); ?>" class="btn btn-info" >Back</a>
</div>
<?php /**PATH C:\YEAR III\laravel\CRUDLARAVEL\ass2laravel\resources\views/employeeview/display.blade.php ENDPATH**/ ?>